<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us - Bangla Kitchen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #ab0404;
            padding: 10px;
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 36px;
            color: #fff;
        }
        main {
            padding: 20px;
        }
        section {
            margin-bottom: 40px;
        }
        h2 {
            font-size: 32px;
            color: #ab0404;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            color: #707070;
            margin-bottom: 20px;
        }
        .team-member {
            text-align: center;
            margin-bottom: 20px;
        }
        .team-member img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
        }
        .team-member h3 {
            margin-top: 10px;
            font-size: 20px;
            color: #1a1a1a;
        }
        .team-member p {
            margin-top: 5px;
            font-size: 16px;
            color: #707070;
        }
        .customer-ratings {
            text-align: center;
        }
        .customer-ratings h4 {
            margin-bottom: 10px;
            font-size: 20px;
            color: #1a1a1a;
        }
        .customer-ratings p {
            margin-bottom: 5px;
            font-size: 18px;
            color: #707070;
        }
        .customer-ratings blockquote {
            margin-top: 20px;
            font-size: 16px;
            color: #707070;
            border-left: none;
        }
        .rating {
            font-size: 24px;
        }
        .rating i {
            color: #ffcc00;
        }
        .additional-info {
            text-align: center;
        }
        .additional-info h3 {
            font-size: 28px;
            color: #ab0404;
            margin-bottom: 10px;
        }
        .additional-info p {
            font-size: 18px;
            color: #707070;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bangla Kitchen</h1>
    </header>
    <main>
        <section>
            <h2>About Us</h2>
            <p>Bangla Kitchen is a Bengali restaurant located in the heart of the city. We specialize in traditional Bengali cuisine and offer a unique dining experience that will leave you wanting more. In addition to our delicious food, we also offer a warm and welcoming atmosphere. Whether you're stopping by for a quick lunch or celebrating a special occasion, we'll make sure you feel right at home.</p>
            <p>Thank you for choosing Bangla Kitchen. We look forward to serving you soon!</p>
        </section>
        <section>
            <h2>Meet Our Team</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="team-member">
                        <img src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/201905/99f29cbb19b71ea9ae21fd72c51bc9.jpeg" alt="Owner">
                        <h3>Mr. AB De Villiers</h3>
                        <p>Owner</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team-member">
                        <img src="../Login-Register/chef.jpg" alt="Chef">
                        <h3>Mr. Rashid Khan</h3>
                        <p>Chef</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team-member">
                        <img src="../Login-Register/waiter.jpg" alt="Waiter">
                        <h3>Mr. Virat Kohli</h3>
                        <p>Waiter</p>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <h2>Customer Ratings</h2>
            <div class="customer-ratings">
                <div class="row">
                    <div class="col-md-4">
                        <div class="customer-rating">
                            <h4>Md.Tamim</h4>
                            <p><span class="rating">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>
                            <blockquote>"Great food and excellent online service. Will definitely order again!"</blockquote>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="customer-rating">
                            <h4>Dewan Abir Mahmud</h4>
                            <p><span class="rating">&#9733;&#9733;&#9733;&#9733;&#9734;</span></p>
                            <blockquote>"The ambiance is fantastic and the food is delicious. Highly recommended!"</blockquote>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="customer-rating">
                            <h4>Shakib Al Hasan</h4>
                            <p><span class="rating">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>
                            <blockquote>"Had a wonderful dining experience. The food was top-notch."</blockquote>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="additional-info">
            <h3>Visit Us Today</h3>
            <p>We are located at 123 Main Street, Sylhet. Come and experience the authentic taste of Bengali cuisine and our warm hospitality. We are open every day from 11:00 AM to 10:00 PM. Reserve your table now or place an order online for delivery or pickup.</p>
        </section>
    </main>
</body>
</html>
