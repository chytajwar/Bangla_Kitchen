<?php

    include 'config.php';

    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_FILES['image'];

    //print_r($image);
    //temporary location
    $imageLocation = $_FILES['image']['tmp_name'];

    $imageName = $_FILES['image']['name'];
    //permanent location(database)
    $img_des = "image/".$imageName;
 
    //echo "<br><br>".$img_des;

    move_uploaded_file($imageLocation, $img_des);

    $insert_query = "INSERT INTO `product`(`name`, `price`, `image`) VALUES ('$name','$price','$img_des')";
    
  if(  mysqli_query($conn,$insert_query))
  {
    echo "<script>alert('Inserted')</script>";
    echo "<script>location.href='index1.php'</script>";
  }
    //echo "<br><br>".$imageLocation;
?>