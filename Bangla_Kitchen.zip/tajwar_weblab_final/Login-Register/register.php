<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <title>Bangla Kitchen - Registration</title>

    <style>
        body {
            background-color: #f8f9fa;
        }

        form {
            background-color: #fff;
            padding: 15px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            max-width: 400px;
            margin: 0 auto;
            margin-top: 100px;
        }
        
        .form-heading {
            text-align: center;
            margin-bottom: 30px;
        }

        .btn-order {
            background-color: #ffc107;
            border-color: #ffc107;
        }
    </style>
  </head>

  <body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="registerAction.php" method="post">
                    <h2 class="form-heading">Bangla Kitchen - Register</h2>
                    <div class="mb-3">
                        <label for="r_username" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="r_username" name="r_username">
                    </div>

                    <div class="mb-3">
                        <label for="r_email" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="r_email" name="r_email">
                    </div>

                    <div class="mb-3">
                        <label for="r_address" class="form-label">Address:</label>
                        <input type="text" class="form-control" id="r_address" name="r_address">
                    </div>

                    <div class="mb-3">
                        <label for="r_pass" class="form-label">Password:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="r_pass" name="r_pass">
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <input type="checkbox" onclick="togglePasswordVisibility()">
                                    Show Password
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="r_con_pass" class="form-label">Confirm Password:</label>
                        <input type="password" class="form-control" id="r_con_pass" name="r_con_pass">
                    </div>

                    <div class="mb-3">
                        <label for="r_phone" class="form-label">Phone:</label>
                        <input type="text" class="form-control" id="r_phone" name="r_phone">
                    </div>
                    
                    <button type="submit" class="btn btn-order col-12">Register</button>
                    Already have an account? <a href="index.php">Login Here</a>
                </form>
            </div>
        </div>
    </div>


    <!-- Bootstrap JS from CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("r_pass");
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>

   </body>
</html>
