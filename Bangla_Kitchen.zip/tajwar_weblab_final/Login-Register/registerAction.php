<?php

    include 'config.php';

    $r_username = $_POST['r_username'];
    $r_email = $_POST['r_email'];
    $r_address = $_POST['r_address'];
    $r_phone = $_POST['r_phone'];
    $r_pass = $_POST['r_pass'];
    $r_con_pass = $_POST['r_con_pass'];

    $username_pattern = "/[A-Za-z .]{3,20}/";
    $email_pattern = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$/";
    $address_pattern = "/[A-Za-z .]{3,20}/";
    $phone_pattern = "/(\+88)?-?01[3-9]\d{8}/";
    $pass_pattern = "/((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&*_+><])).{6,20}/";

    $duplicate_username = mysqli_query($conn, "SELECT * FROM `register` WHERE db_username='$r_username'");
    $duplicate_email = mysqli_query($conn, "SELECT * FROM `register` WHERE db_email='$r_email'");
    
    if (mysqli_num_rows($duplicate_username) > 0 && mysqli_num_rows($duplicate_email) > 0) {
        echo "<script>alert('Username and Email are already taken')</script>";
        echo "<script>location.href='register.php'</script>";
    } elseif (mysqli_num_rows($duplicate_username) > 0) {
        echo "<script>alert('Username is already taken')</script>";
        echo "<script>location.href='register.php'</script>";
    } elseif (mysqli_num_rows($duplicate_email) > 0) {
        echo "<script>alert('Email is already taken')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif(!preg_match($username_pattern, $r_username))
    {
        echo "<script>alert('Invalid Username')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif(!preg_match($email_pattern, $r_email))
    {
        echo "<script>alert('Invalid Email')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif(!preg_match($address_pattern, $r_address))
    {
        echo "<script>alert('Invalid Address')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif(!preg_match($phone_pattern, $r_phone))
    {
        echo "<script>alert('Invalid Phone Number')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif(!preg_match($pass_pattern, $r_pass))
    {
        echo "<script>alert('Invalid Password')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    elseif($r_pass!=$r_con_pass)
    {
        echo "<script>alert('Password not matched')</script>";
        echo "<script>location.href='register.php'</script>";
    }

    else
    {
        $insert_query = "INSERT INTO `register`(`db_username`, `db_email`, `db_phone`, `db_address`, `db_pass`) VALUES ('$r_username','$r_email','$r_phone','$r_address','$r_pass')";
        if(!mysqli_query($conn, $insert_query))
        {
            die("Not Inserted...!!!");
        }
        else
        {
            echo "<script>alert('Inserted')</script>";
            echo "<script>location.href='register.php'</script>";
        }
    }

?>