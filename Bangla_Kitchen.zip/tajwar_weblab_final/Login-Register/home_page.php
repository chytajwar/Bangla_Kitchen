<?php
session_start();

// Check if the "Add to Cart" button is clicked
if (isset($_POST['add_to_cart'])) {
    // Retrieve the item details
    $item_name = $_POST['item_name'];
    $item_price = $_POST['item_price'];

    // Create a new cart item
    $cart_item = array(
        'name' => $item_name,
        'price' => $item_price
    );

    // Add the item to the cart session variable
    $_SESSION['cart'][] = $cart_item;
}

// Database connection details
$db_host = 'localhost';
$db_user = "root";
$db_pass = '';
$db_name = 'web_final_project';

// Create a database connection
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Store cart details in the database
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    // Get user input for username and address
    $username = isset($_SESSION['l_username']) ? $_SESSION['l_username'] : '';

    $total_price = 0;

    // Calculate the total price
    foreach ($_SESSION['cart'] as $item) {
        $total_price += floatval($item['price']);
    }

    // Prepare the SQL query with parameter placeholders
    $sql = "INSERT INTO add_to_cart (username, total_price) VALUES (?, ?)";

    // Create a prepared statement
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'sd', $username, $total_price);

    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        // Clear the cart session variable after successful database insertion
        $_SESSION['cart'] = array();
    } else {
        echo 'Error: ' . mysqli_error($conn);
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bangla Kitchen - popular Menus</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('https://img.freepik.com/free-photo/black-surface-with-slight-spots_1194-7667.jpg?w=900&t=st=1687711548~exp=1687712148~hmac=d1303a4f455b0b5802641c6cc1702cd962e50cd469a46f722b66e98dcb82c35b');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
        }

        .container {
            padding: 20px;
            margin-top: 35px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .item {
            margin-bottom: 20px;
        }

        .item img {
            width: 300px;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
        }

        .item h2 {
            margin: 10px 0;
            font-size: 18px;
            line-height: 1.2;
        }

        .item .price {
            font-size: 16px;
            color: #999;
            margin-bottom: 5px;
        }

        .item .rating {
            color: #ffbf00;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .item .emoji {
            font-size: 18px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Bangla Kitchen - Hot Deals Today<span class="emoji">🔥</span></h1>
        <div class="row">
            <div class="col-md-6">
                <div class="item">
                    <img src="https://indiafoodnetwork.in/wp-content/uploads/2017/03/ilish.jpg" alt="Rice With Shorse Ilish">
                    <h2>Rice With Shorse Ilish</h2>
                    <div class="price">Tk.280</div>
                    <div class="rating">Rating: 4.5/5 <span class="emoji">🔥</span></div>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Rice With Shorse Ilish">
                        <input type="hidden" name="item_price" value="280">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="https://i0.wp.com/www.lightandcomposition.com/wp-content/uploads/beef_tehari_06.jpg?fit=845%2C564&ssl=1" alt="Beef Akhni">
                    <h2>Beef Akhni</h2>
                    <p class="price">Tk.150</p>
                    <p class="rating">Rating: 5.0/5 <span class="emoji">🔥</span></p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Beef Akhni">
                        <input type="hidden" name="item_price" value="150">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="https://i.ytimg.com/vi/v1MGvONjF0o/maxresdefault.jpg" alt="Dawat Platter">
                    <h2>Dawat Platter</h2>
                    <p class="price">Tk.300</p>
                    <p class="rating">Rating: 5.0/5 <span class="emoji">🔥</span></p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Dawat Platter">
                        <input type="hidden" name="item_price" value="300">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="https://static.wixstatic.com/media/f319d7_1264082660c5470880a01c9ba1874e05~mv2.jpg/v1/fit/w_1000%2Ch_1000%2Cal_c%2Cq_80,enc_auto/file.jpg" alt="Bhartas With Rice">
                    <h2>Bhartas With Rice</h2>
                    <p class="price">Tk.100</p>
                    <p class="rating">Rating: 5.0/5 <span class="emoji">🔥</span></p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Bhartas With Rice">
                        <input type="hidden" name="item_price" value="100">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

