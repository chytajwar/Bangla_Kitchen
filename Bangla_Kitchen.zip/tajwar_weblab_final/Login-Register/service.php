<!DOCTYPE html>
<html>
<head>
    <title>Bangla Kitchen - Services</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            padding: 20px;
        }
        
        .service-title {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
            color: #ab0404;
        }
        .service-item {
            margin-bottom: 40px;
            display: flex;
            align-items: center;
        }
        .service-item img {
            width: 400px;
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
            margin-right: 20px;
        }
        .service-item-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #ab0404;
        }
        .service-item-desc {
            font-size: 18px;
            color: #555;
            line-height: 1.5;
            text-align: justify;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="service-title">Bangla Kitchen - Services</h1>
        
        <div class="service-item">
            <img src="https://www.sunjaya.com.my/wp-content/uploads/2019/11/Wedding-Catering-Fusion.jpg" alt="Catering">
            <div>
                <h2 class="service-item-title">Catering</h2>
                <p class="service-item-desc">We offer exceptional catering services for parties, and corporate events. Our team of talented chefs and dedicated staff ensures a delightful culinary experience for you and your guests. From customized menus to impeccable service, we take care of every detail to make your event a success.</p>
            </div>
        </div>
        
        <div class="service-item">
            <img src="https://i.ytimg.com/vi/XKYwyshH1yY/sddefault.jpg" alt="Private Events">
            <div>
                <h2 class="service-item-title">Private Events</h2>
                <p class="service-item-desc">Celebrate your special moments with us! Our elegant and versatile event spaces are perfect for hosting private events like weddings, anniversaries, and family gatherings. With our delectable cuisines, professional service, and attention to detail, we create an ambiance that leaves a lasting impression on your guests.</p>
            </div>
        </div>
        
        <div class="service-item">
            <img src="https://img.freepik.com/free-photo/food-delivery-boy-delivering-food-scooter_1303-27695.jpg?size=626&ext=jpg&ga=GA1.2.1339164147.1676104753&semt=ais" alt="Delivery">
            <div>
                <h2 class="service-item-title">Delivery</h2>
                <p class="service-item-desc">Enjoy the flavors of Bangla Kitchen in the comfort of your home. We offer reliable and convenient food delivery services. Browse our menu online, place your order, and our dedicated delivery team will ensure that your favorite dishes are delivered fresh and hot to your doorstep. Experience the convenience of restaurant-quality meals without leaving your home!</p>
            </div>
        </div>
    </div>
</body>
</html>
