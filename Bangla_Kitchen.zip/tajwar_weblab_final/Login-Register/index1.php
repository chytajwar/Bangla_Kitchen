<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <title>Food Ordering App</title>

    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        form {
            background: #ffffff;
            padding: 15px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h5 {
            color: #dc3545;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            color: #343a40;
            font-weight: bold;
        }

        input[type="text"],
        input[type="file"] {
            background-color: #f2f2f2;
            color: #343a40;
            border-color: #ced4da;
        }

        .btn-primary {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .table thead th {
            background-color: #343a40;
            color: #ffffff;
            font-weight: bold;
            border-color: #454d55;
        }

        .btn-warning,
        .btn-danger {
            font-size: 14px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6 col-sm-12">
                <form action="insert.php" method="post" enctype="multipart/form-data">
                    <h5>Product Insert Form</h5>
                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label">Product Price:</label>
                        <input type="text" class="form-control" id="price" name="price" required>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Product Image:</label>
                        <input type="file" class="form-control" id="image" name="image" required>
                    </div>

                    <button type="submit" class="btn btn-primary col-12">Insert</button>
                </form>
            </div>
        </div>

        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Product Price</th>
                    <th scope="col">Image</th>
                    <th scope="col">Update</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>

            <tbody>
                <?php
                include 'config.php';

                $allData = mysqli_query($conn, "SELECT * FROM `product`");

                while ($row = mysqli_fetch_array($allData)) {
                    echo "
                        <tr>                               
                            <td>$row[id]</td>
                            <td>$row[name]</td>
                            <td>$row[price]</td>
                            <td> <img width='100px' src='$row[image]' alt=''></td>
                            <td><a class='btn btn-warning btn-sm' href='update.php?id=$row[id]'>Update</a></td>
                            <td><a class='btn btn-danger btn-sm' href='delete.php? id=$row[id]'>Delete</a></td>
                        </tr>
                    ";
                }
                ?>
            </tbody>
        </table>
    </div>


    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
