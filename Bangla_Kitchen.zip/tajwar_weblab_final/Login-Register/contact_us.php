<!DOCTYPE html>
<html>
<head>
    <title>Bangla Kitchen - Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('https://img.freepik.com/free-photo/black-surface-with-slight-spots_1194-7667.jpg?w=900&t=st=1687711548~exp=1687712148~hmac=d1303a4f455b0b5802641c6cc1702cd');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
        }

        .container {
            padding: 20px;
            margin-top: 35px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            margin-top: 20px;
            text-align: center;
        }

        .contact-info {
            margin-top: 30px;
            text-align: center;
        }

        .contact-info p {
            margin-bottom: 5px;
        }

        .contact-info i {
            margin-right: 10px;
        }

        .contact-form {
            margin-top: 30px;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .contact-form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .contact-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contact Us</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="contact-info">
                    <h3>Our Address</h3>
                    <p><i class="fas fa-map-marker-alt"></i>123 Main Street, Sylhet, Bangladesh</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-info">
                    <h3>Contact Information</h3>
                    <p><i class="fas fa-phone"></i> +1 123-456-7890</p>
                    <p><i class="fas fa-envelope"></i> info@banglakitchen.com</p>
                </div>
            </div>
        </div>
        <div class="contact-form">
            <h3>Send us a Message</h3>
            <form method="post" action="contact.php">
                <div class="form-group">
                    <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <textarea class="form-control" name="message" placeholder="Your Message" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
