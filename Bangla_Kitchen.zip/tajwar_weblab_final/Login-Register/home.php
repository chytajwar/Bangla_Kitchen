<?php
    session_start();
    echo "Hello Assalamualaikum";
    if(isset($_SESSION['l_username'])){
        echo "<h3> Welcome ".$_SESSION['l_username']. " to Our Website</h3>";
        
        include 'Main.html';
    }
    else{
        echo "<script>alert('Do not access from URL')</script>";
        echo "<script>location.href='index.php'</script>";
    }


   
?> 