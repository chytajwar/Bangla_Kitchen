<?php
session_start();

// Check if the "Add to Cart" button is clicked
if (isset($_POST['add_to_cart'])) {
    // Retrieve the item details
    $item_name = $_POST['item_name'];
    $item_price = $_POST['item_price'];

    // Create a new cart item
    $cart_item = array(
        'name' => $item_name,
        'price' => $item_price
    );

    // Add the item to the cart session variable
    $_SESSION['cart'][] = $cart_item;
}

// Database connection details
$db_host = 'localhost';
$db_user = "root";
$db_pass = '';
$db_name = 'web_final_project';

// Create a database connection
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Store cart details in the database
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    // Get user input for username and address
    $username = isset($_SESSION['l_username']) ? $_SESSION['l_username'] : '';

    // Get the total price from the session
    $total_price = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total_price += floatval($item['price']);
    }

    // Prepare the SQL query with parameter placeholders
    $sql = "INSERT INTO add_to_cart (username, total_price) VALUES (?, ?)";

    // Create a prepared statement
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'sd', $username, $total_price);

    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        // Clear the cart session variable after successful database insertion
        $_SESSION['cart'] = array();
    } else {
        echo 'Error: ' . mysqli_error($conn);
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bangla Kitchen - Breakfast Menu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
    background-image: url('https://img.freepik.com/free-photo/restaurant-with-green-wall-wooden-table-with-row-tables-planter-with-plant-background_188544-37710.jpg?t=st=1687708903~exp=1687709503~hmac=b7b90b44d4efe7983c6c1b905a9286f552a4573b7285bee40a3434fe76cb348f&w=1060');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    background-attachment: fixed;
    height: 100vh;
    width: 100%;
}


        .container {
            padding: 20px;
            margin-top: 35px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .item {
            margin-bottom: 20px;
        }

    .item {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}

.item img {
    width: 300px;
    height: 200px;
    object-fit: cover;
    border-radius: 5px;
}


        .item h2 {
            margin: 10px 0;
            font-size: 18px;
            line-height: 1.2;
        }

        .item .price {
            font-size: 16px;
            color: #999;
            margin-bottom: 5px;
        }

        .item .rating {
            color: #ffbf00;
            font-size: 16px;
            margin-bottom: 5px;
        }

        #total_price {
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            text-align: center;
        }
    </style>
    <script>
        // Function to calculate the total price
        function calculateTotalPrice() {
            var totalPrice = 0;
            var priceInputs = document.querySelectorAll('.item input[name="item_price"]');

            for (var i = 0; i < priceInputs.length; i++) {
                var price = parseFloat(priceInputs[i].value);
                totalPrice += price;
            }

            document.getElementById('total_price').textContent = 'Total Price: Tk. ' + totalPrice.toFixed(2);
        }

        // Add event listeners to the "Add to Cart" buttons
        var addToCartButtons = document.querySelectorAll('.item button[name="add_to_cart"]');
        for (var i = 0; i < addToCartButtons.length; i++) {
            addToCartButtons[i].addEventListener('click', calculateTotalPrice);
        }
    </script>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Bangla Kitchen - Breakfast Menus</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="item">
                    <img src="https://cookishcreation.com/wp-content/uploads/2022/05/Beef-Khichuri-Cookish-Creation.jpg" alt="Beef Bhuna Khichuri" class="image-fluid">
                    <h2>Beef Bhuna Khichuri</h2>
                    <div class="price">Tk. 140</div>
                    <div class="rating">Rating: 4.4/5</div>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Beef Bhuna Khichuri">
                        <input type="hidden" name="item_price" value="140">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="../Login-Register/paratha with other items.jpg" alt="3 in 1" class="image-fluid">
                    <h2>3 in 1</h2>
                    <div class="price">Tk. 90</div>
                    <div class="rating">Rating: 4.0/5</div>
                    <form method="post">
                        <input type="hidden" name="item_name" value="3 in 1">
                        <input type="hidden" name="item_price" value="90">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="total_price" class="text-center"></div>
    </div>
</body>
</html>
