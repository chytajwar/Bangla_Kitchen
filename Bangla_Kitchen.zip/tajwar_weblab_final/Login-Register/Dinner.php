<?php
session_start();

// Check if the "Add to Cart" button is clicked
if (isset($_POST['add_to_cart'])) {
    // Retrieve the item details
    $item_name = $_POST['item_name'];
    $item_price = $_POST['item_price'];

    // Create a new cart item
    $cart_item = array(
        'name' => $item_name,
        'price' => $item_price
    );

    // Add the item to the cart session variable
    $_SESSION['cart'][] = $cart_item;
}

// Database connection details
$db_host = 'localhost';
$db_user = "root";
$db_pass = '';
$db_name = 'web_final_project';

// Create a database connection
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Store cart details in the database
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    // Get user input for username and address
    $username = isset($_SESSION['l_username']) ? $_SESSION['l_username'] : '';
   
    $total_price = 0;

    // Calculate the total price
    foreach ($_SESSION['cart'] as $item) {
        $total_price += floatval($item['price']);
    }

    // Prepare the SQL query with parameter placeholders
    $sql = "INSERT INTO add_to_cart (username,  total_price) VALUES (?, ?)";

    // Create a prepared statement
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'sd', $username,  $total_price);

    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        // Clear the cart session variable after successful database insertion
        $_SESSION['cart'] = array();
    } else {
        echo 'Error: ' . mysqli_error($conn);
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bangla Kitchen - Dinner Menus</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('https://www.blackarchitecture.dk/wp-content/uploads/2022/05/BLK-ARCH_UMI_M-OMME_20220410_946_WEB.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
        }

        .container {
            padding: 20px;
            margin-top: 35px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .item {
            margin-bottom: 20px;
        }

        .item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
        }

        .item h2 {
            margin: 10px 0;
            font-size: 18px;
            line-height: 1.2;
        }

        .item .price {
            font-size: 16px;
            color: #999;
            margin-bottom: 5px;
        }

        .item .rating {
            color: #ffbf00;
            font-size: 16px;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Bangla Kitchen - Dinner Menus</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="item">
                    <img src="../Login-Register/kacchi biriyani.jpg" alt="Kacchi Biriyani" class="image-fluid">
                    <h2>Kacchi Biriyani</h2>
                    <div class="price">Tk.230</div>
                    <div class="rating">Rating: 4.1/5</div>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Kacchi Biriyani">
                        <input type="hidden" name="item_price" value="230">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="../Login-Register/Combo Dinner.jpg" alt="Combo Dinner" class="image-fluid">
                    <h2>Combo Dinner</h2>
                    <p class="price">Tk.220</p>
                    <p class="rating">Rating: 4.3/5</p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Combo Dinner">
                        <input type="hidden" name="item_price" value="220">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="https://family-images-y24bv7yxalct4.azureedge.net/families/8826/8826_background_1984x900.webp" alt="Plain Rice With Beef Bhuna" class="image-fluid">
                    <h2>Plain Rice With Beef Bhuna</h2>
                    <p class="price">Tk.260</p>
                    <p class="rating">Rating: 4.1/5</p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Plain Rice With Beef Bhuna">
                        <input type="hidden" name="item_price" value="260">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="item">
                    <img src="../Login-Register/payesh.jpg" alt="Payesh" class="image-fluid">
                    <h2>Payesh</h2>
                    <p class="price">Tk.80</p>
                    <p class="rating">Rating: 5.0/5</p>
                    <form method="post">
                        <input type="hidden" name="item_name" value="Payesh">
                        <input type="hidden" name="item_price" value="80">
                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

