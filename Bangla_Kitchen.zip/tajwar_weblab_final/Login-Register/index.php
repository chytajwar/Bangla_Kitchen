<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <title>Bangla Kitchen - Login</title>

    <style>
        body {
            background-color: #f8f9fa;
        }

        form {
            background-color: #fff;
            padding: 15px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            max-width: 400px;
            margin: 0 auto;
            margin-top: 100px;
        }
        
        .form-heading {
            text-align: center;
            margin-bottom: 30px;
        }

        .btn-order {
            background-color: #ffc107;
            border-color: #ffc107;
        }
    </style>
  </head>

  <body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="loginAction.php" method="post">
                    <h2 class="form-heading">Bangla Kitchen - Login</h2>
                    <div class="mb-3">
                        <label for="l_username" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="l_username" name="l_username">
                    </div>

                    


                    <div class="mb-3">
                        <label for="l_pass" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="l_pass" name="l_pass">
                    </div>
                    
                    <button type="submit" class="btn btn-order col-12">Login</button>
                    New user? <a href="register.php">Register Here</a>
                </form>
            </div>
        </div>
    </div>


    <!-- Bootstrap JS from CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

   </body>
</html>
